package com.noole.lab8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.noole.lab8.services.Service1;
import com.noole.lab8.services.Service2;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnService2start).setOnClickListener(view -> {
            Intent service2_start = new Intent(getApplicationContext(), Service2.class);
            startService(service2_start);
        });

        findViewById(R.id.btnService2Stop).setOnClickListener(view -> {
            Intent service2_stop = new Intent(getApplicationContext(), Service2.class);
            stopService(service2_stop);
        });

        findViewById(R.id.button4).setOnClickListener(view -> {
            startActivity(new Intent(MainActivity.this,SecondActivity2.class));
        });
    }
}